

/*
Author: Bantwal Vaibhav Mallya 
Class: ECE 6122 A
Last Modified Date: 5th December 2023

File Description:

This file is for keyboard inputs to control movements of suzanne heads 
*/

// Include GLFW
#include <glfw3.h>
extern GLFWwindow* window; // The "extern" keyword here is to access the variable "window" declared in tutorialXXX.cpp. This is a hack to keep the tutorials simple. Please avoid this.

// Include GLM
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
using namespace glm;

#include "controls.hpp"

glm::mat4 ViewMatrix;
glm::mat4 ProjectionMatrix;

glm::mat4 getViewMatrix(){
	return ViewMatrix;
}
glm::mat4 getProjectionMatrix(){
	return ProjectionMatrix;
}


// Initial position : on +Z
glm::vec3 position = glm::vec3( 0.0f, 0.0f, 12.0f); 
// Initial horizontal angle : toward -Z
float horizontalAngle = 0.01f;
// Initial vertical angle : none
float verticalAngle = 0.01f;
// Initial Field of View
float initialFoV = 45.0f;

float radius = 12.0f;

void updateNewCameraPosition(){
    float x = radius * sin(verticalAngle) * cos(horizontalAngle);
    float y = radius * sin(verticalAngle) * sin(horizontalAngle);
    float z = radius * cos(verticalAngle);
    position = glm::vec3(x,y,z);
}


void computeMatricesFromInputs(){

	// glfwGetTime is called only once, the first time this function is called
	static double lastTime = glfwGetTime();

	// Compute time difference between current and last frame
	double currentTime = glfwGetTime();
	float deltaTime = float(currentTime - lastTime);
        

	//initial up vector 

	glm::vec3 up = glm::vec3(0.0f,0.0f,1.0f);
	//up = glm::normalize(up);
	

	// Move forward
	if (glfwGetKey( window, GLFW_KEY_UP ) == GLFW_PRESS){
	        
	  //position += forward * deltaTime * speed;
	  radius -= 0.05f;
	  //updateNewCameraPosition();
	}
	// Move backward
	if (glfwGetKey( window, GLFW_KEY_DOWN ) == GLFW_PRESS){
	  //radius += 0.01f;
          radius += 0.05f;
	  
	}
	//Rotate right
	if (glfwGetKey( window, GLFW_KEY_RIGHT ) == GLFW_PRESS){
	        
	horizontalAngle += 0.01f; //rotating the camera right radially so angle increases when "D" is pressed 
	    
	 }
	//Rotate left
	if (glfwGetKey( window, GLFW_KEY_LEFT ) == GLFW_PRESS){
	        horizontalAngle -= 0.01f; //rotating the camera left radially so angle decreases when "A" is pressed 
		   //}
	        
        
		   
	}
	//Move radially up
	if (glfwGetKey( window, GLFW_KEY_U ) == GLFW_PRESS){
        
		   verticalAngle -= 0.01f; //rotating the camera radially up so angle increases when UP key is pressed
		   
		   if(verticalAngle < 0.0f){
		     verticalAngle = 0.0f;
		   }
		   if(verticalAngle > 3.14f){
		     verticalAngle = 3.14f;
		   }
		  
		   

		   
	}
	//Move radially down
	if (glfwGetKey( window, GLFW_KEY_D ) == GLFW_PRESS){
	 
	        verticalAngle += 0.01f; 
		
		if(verticalAngle < 0.0f){
		     verticalAngle = 0.0f;
		}
		if(verticalAngle > 3.14f){
		     verticalAngle = 3.14f;
		}
		
	        
		
	}

	position.x = radius * sin(verticalAngle) * cos(horizontalAngle);
	position.y = radius * sin(verticalAngle) * sin(horizontalAngle);
	position.z = radius * cos(verticalAngle);
	
	float FoV = initialFoV;// - 5 * glfwGetMouseWheel(); // Now GLFW 3 requires setting up a callback for this. It's a bit too complicated for this beginner's tutorial, so it's disabled instead.

	// Projection matrix : 45° Field of View, 4:3 ratio, display range : 0.1 unit <-> 100 units
	ProjectionMatrix = glm::perspective(FoV, 4.0f / 3.0f, 0.1f, 100.0f);
	// Camera matrix
	ViewMatrix       = glm::lookAt(
   		position,//camera is here 
   		glm::vec3(0.0f,0.0f,0.0f),// Camera looks here
   		up// Head is up (set to 0,-1,0 to look upside-down)
   	);

	// For the next frame, the "last time" will be "now"
	lastTime = currentTime;
}
